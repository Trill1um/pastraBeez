const AboutPage=  () => {
    return (
        <div className="min-h-screen w-full flex items-center justify-center">
            <h1 className="bee-logo-desktop text-4xl text-yellow-700">About Us Page Coming Soon!</h1>
        </div>
    );
};

export default AboutPage;